angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('inicio', {
    url: '/page1',
    templateUrl: 'templates/inicio.html',
    controller: 'inicioCtrl'
  })

  .state('entrarMaterial', {
    url: '/page2',
    templateUrl: 'templates/entrarMaterial.html',
    controller: 'entrarMaterialCtrl'
  })

  .state('salidaMaterial', {
    url: '/page5',
    templateUrl: 'templates/salidaMaterial.html',
    controller: 'salidaMaterialCtrl'
  })

  .state('formuarioEntrada', {
    url: '/page3',
    templateUrl: 'templates/formuarioEntrada.html',
    controller: 'formuarioEntradaCtrl'
  })

  .state('formuarioSalida', {
    url: '/page6',
    templateUrl: 'templates/formuarioSalida.html',
    controller: 'formuarioSalidaCtrl'
  })

  .state('listadoEntradasSalidas', {
    url: '/page7',
    templateUrl: 'templates/listadoEntradasSalidas.html',
    controller: 'listadoEntradasSalidasCtrl'
  })

  .state('materialDentroDeLaNave', {
    url: '/page8',
    templateUrl: 'templates/materialDentroDeLaNave.html',
    controller: 'materialDentroDeLaNaveCtrl'
  })

  .state('materialFueraDeLaNave', {
    url: '/page9',
    templateUrl: 'templates/materialFueraDeLaNave.html',
    controller: 'materialFueraDeLaNaveCtrl'
  })

  .state('etapas', {
    url: '/page10',
    templateUrl: 'templates/etapas.html',
    controller: 'etapasCtrl'
  })

  .state('etapas2', {
    url: '/page12',
    templateUrl: 'templates/etapas2.html',
    controller: 'etapas2Ctrl'
  })

  .state('editarEtapas', {
    url: '/page11',
    templateUrl: 'templates/editarEtapas.html',
    controller: 'editarEtapasCtrl'
  })

  .state('editarEtapas2', {
    url: '/page13',
    templateUrl: 'templates/editarEtapas2.html',
    controller: 'editarEtapas2Ctrl'
  })

  .state('calendario', {
    url: '/page14',
    templateUrl: 'templates/calendario.html',
    controller: 'calendarioCtrl'
  })

  .state('editar', {
    url: '/page18',
    templateUrl: 'templates/editar.html',
    controller: 'editarCtrl'
  })

  .state('eventos', {
    url: '/page15',
    templateUrl: 'templates/eventos.html',
    controller: 'eventosCtrl'
  })

  .state('editarEventos', {
    url: '/page16',
    templateUrl: 'templates/editarEventos.html',
    controller: 'editarEventosCtrl'
  })

  .state('tCnicos', {
    url: '/page17',
    templateUrl: 'templates/tCnicos.html',
    controller: 'tCnicosCtrl'
  })

  .state('inicieSesiN', {
    url: '/page19',
    templateUrl: 'templates/inicieSesiN.html',
    controller: 'inicieSesiNCtrl'
  })

$urlRouterProvider.otherwise('/page1')


});